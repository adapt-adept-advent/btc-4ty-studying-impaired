import random
from bitcoinlib.keys import HDKey

def generate_address(address_type):
    key = HDKey()
    if address_type == "legacy":
        address = key.address()
    elif address_type == "segwit":
        address = key.segwit_address()
    elif address_type == "taproot":
        address = key.taproot_address()
    else:
        raise ValueError("Invalid address type")
    return {
        "address": address,
        "private_key": key.private_hex,
        "public_key": key.public_hex,
        "wif": key.wif,
        "master_key": key.master_key,
    }

def send_money(recipient, block_height):
    # Simulate transaction; in production, build, sign, and broadcast Bitcoin tx
    txid = f"tx-{random.randint(100000, 999999)}"
    # Broadcasting would go here, e.g., using requests to Blockstream or Mempool APIs
    return {"recipient": recipient, "block_height": block_height, "txid": txid}