from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from toolkit import generate_address, send_money

from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Enable CORS for frontend dev/demo
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class AddressRequest(BaseModel):
    type: str  # "legacy", "segwit", "taproot"

@app.post("/generate-address")
def generate_address_api(request: AddressRequest):
    try:
        result = generate_address(request.type)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

class SendMoneyRequest(BaseModel):
    recipient: str
    block_height: int

@app.post("/send-money")
def send_money_api(request: SendMoneyRequest):
    try:
        result = send_money(request.recipient, request.block_height)
        return {"status": "success", "data": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))