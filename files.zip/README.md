# Bitcoin UTXO Toolkit Demo

A step-by-step wizard for generating Bitcoin addresses and simulating transactions with FastAPI & React.

## How to Run Locally

1. **Clone and unzip project**

2. **Start Docker Compose**

```bash
docker-compose up --build
```

- Backend: [http://localhost:8000/docs](http://localhost:8000/docs)
- Frontend: [http://localhost:3000](http://localhost:3000)

## Deploy a Live Demo (Free!)

- [Replit](https://replit.com/) — Copy both backend and frontend as separate repls.
- [Railway](https://railway.app/) — Import from GitHub and deploy both services.
- [Render](https://render.com/) — Create two services, one for backend (FastAPI), one for frontend (React).

## Project Structure

See the code files in this repo for details.

---

**Note:** The transaction broadcast is simulated for demo purposes. For real Bitcoin handling, add comprehensive transaction logic and secure key management!