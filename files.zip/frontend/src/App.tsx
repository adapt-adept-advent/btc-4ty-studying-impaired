import React, { useState } from "react";
import { generateAddress, sendMoney } from "./api";

function App() {
  const [step, setStep] = useState(1);
  const [addressType, setAddressType] = useState("");
  const [addressData, setAddressData] = useState<any>(null);
  const [blockHeight, setBlockHeight] = useState("");
  const [recipient, setRecipient] = useState("");
  const [transaction, setTransaction] = useState<any>(null);

  const handleGenerateAddress = async () => {
    const result = await generateAddress(addressType);
    setAddressData(result.data);
    setStep(2);
  };

  const handleSendMoney = async () => {
    const result = await sendMoney(recipient, Number(blockHeight));
    setTransaction(result.data);
    setStep(4);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial, sans-serif" }}>
      <h1>Bitcoin Wizard Demo</h1>
      {step === 1 && (
        <div>
          <h2>Step 1: Choose Address Type</h2>
          <select onChange={(e) => setAddressType(e.target.value)} value={addressType}>
            <option value="">Select Address Type</option>
            <option value="legacy">Legacy</option>
            <option value="segwit">SegWit</option>
            <option value="taproot">Taproot</option>
          </select>
          <br />
          <button onClick={handleGenerateAddress} disabled={!addressType} style={{marginTop: 10}}>Generate Address</button>
        </div>
      )}

      {step === 2 && addressData && (
        <div>
          <h2>Step 2: Generated Address</h2>
          <pre>{JSON.stringify(addressData, null, 2)}</pre>
          <button onClick={() => setStep(3)}>Next</button>
        </div>
      )}

      {step === 3 && (
        <div>
          <h2>Step 3: Enter Block Height</h2>
          <input
            type="number"
            value={blockHeight}
            onChange={(e) => setBlockHeight(e.target.value)}
            placeholder="Enter Block Height"
          />
          <h2>Step 4: Enter Recipient Address</h2>
          <input
            type="text"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            placeholder="Enter Recipient Address"
          />
          <br />
          <button onClick={handleSendMoney} disabled={!blockHeight || !recipient} style={{marginTop: 10}}>Send Money</button>
        </div>
      )}

      {step === 4 && transaction && (
        <div>
          <h2>Transaction Complete</h2>
          <pre>{JSON.stringify(transaction, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default App;