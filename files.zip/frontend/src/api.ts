import axios from "axios";
const API_BASE_URL = "http://localhost:8000";

export const generateAddress = async (addressType: string) => {
  const response = await axios.post(`${API_BASE_URL}/generate-address`, { type: addressType });
  return response.data;
};

export const sendMoney = async (recipient: string, blockHeight: number) => {
  const response = await axios.post(`${API_BASE_URL}/send-money`, { recipient, block_height: blockHeight });
  return response.data;
};